package wzk.experiment.eighth;

/**
 * @author PlagueWZK
 * description: FruitI
 * date: 2025/1/2 20:09
 */

public interface Test {
    void transport();
}
