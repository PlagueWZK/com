package wzk.experiment.fourth;

/**
 * @author PlagueWZK
 * description: Generic
 * date: 2025/1/2 21:08
 */

public interface Generic<T> {
    T get(T t);
}
