package wzk.experiment.seventh;

/**
 * @author PlagueWZK
 * description: Solution
 * date: 2025/1/2 19:38
 */

public class Solution {
}
