package wzk.experiment.seventh;

/**
 * @author PlagueWZK
 * description: Banana
 * date: 2025/1/2 19:38
 */

public class Banana extends Fruit {
}
