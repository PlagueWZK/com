package wzk.experiment.eighteenth;

/**
 * @author PlagueWZK
 * description: Solution
 * date: 2025/1/2 21:29
 */

public class Solution {

}
